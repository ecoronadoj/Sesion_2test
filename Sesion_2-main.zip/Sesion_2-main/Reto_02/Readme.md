# Reto 2.

Considere el data frame `mtcars` de `R` y utilice las funciones `str`, `summary`, `head` y `View` para observar las características del objeto y tener una mayor comprensión de este.
